<template>
  <div style="padding: 30px 0; text-align: center; line-height: 30px">
    <div>社区养老系统 客服电话 010-55669988</div>
   <div> CopyRight© 2001-2023 项目训练营版权所有</div>
  </div>
</template>

<script>
export default {
  name: "Footer",
  data() {
    return {}
  },
  created() {

  },
  methods: {}
}
</script>

<style scoped>

</style>